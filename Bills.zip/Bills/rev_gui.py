from tkinter import *
import tkinter.messagebox

# ========= defined all variables:





def custom_quit():
    answer = tkinter.messagebox.askokcancel('Are You Sure?','For Exit That Software')
    if answer:
        quit()


























root = Tk()
root.geometry("950x800")
root.title('BILL APP WITH MAYUR THORAT')
title = Label(root,text='BILL SOFTWARE',font=('times new romen',30,'bold'),fg='white',bg='red',relief=GROOVE,bd=7)
title.pack(fill=BOTH)

Soap = IntVar()
Face_Cream = IntVar()
Face_Wash = IntVar()
Hair_Spray = IntVar()
Hair_Gel = IntVar()
Body_Loshan = IntVar()

#######

Rice = IntVar()
Food_Oil = IntVar()
Daal = IntVar()
Wheat = IntVar()
Sugar = IntVar()
Tea = IntVar()

#######

Maza = IntVar()
Cock = IntVar()
Frooti = IntVar()
Thumbs_Up = IntVar()
Limca = IntVar()
Sprite = IntVar()

#########

Cosmetic_Price = StringVar()
Grocery_Price = StringVar()
Cold_Drink_Price = StringVar()

Cosmetic_Tax = StringVar()
Grocery_Tax = StringVar()
Cold_Drink_Tax = StringVar()

######

C_Name = StringVar()
Phone_No = StringVar()
Bill_No = StringVar()

Search_Bill = StringVar()

def total():

    C_S_P = Soap.get()*20
    C_FC_P = Face_Cream.get()*120
    C_FW_P = Face_Wash.get()*50
    C_HS_P = Hair_Spray.get()*80
    C_HG_P = Hair_Gel.get()*100
    C_BL_P = Body_Loshan.get()*50

    total_Cosmetic_Price = float(
        C_S_P+
        C_FC_P+
        C_FW_P+
        C_HS_P+
        C_HG_P+
        C_BL_P
    )
    Cosmetic_Price.set("Rs. " + str(total_Cosmetic_Price))
    C_tax = round((total_Cosmetic_Price * 0.05), 2)
    Cosmetic_Tax.set("Rs. " + str(C_tax))


    #######
    G_R_P = Rice.get()*110
    G_F_P = Food_Oil.get()*200
    G_D_P = Daal.get()*90
    G_W_P = Wheat.get()*60
    G_S_P = Sugar.get()*80
    G_T_P = Tea.get()*20

    total_Grocery_Price = float(
        G_R_P+
        G_F_P+
        G_D_P+
        G_W_P+
        G_S_P+
        G_T_P
    )


    Grocery_Price.set("Rs. "+str(total_Grocery_Price))
    G_Tax = round((total_Grocery_Price*0.1),2)
    Grocery_Tax.set("Rs. "+str(G_Tax))

    ###########

    C_M_P = Maza.get()*40
    C_C_P = Cock.get()*50
    C_F_P = Frooti.get()*60
    C_T_P = Thumbs_Up.get()*60
    C_L_P = Limca.get()*50
    C_S_P = Sprite.get()*70

    total_Cold_Drinks_Price = float(
        C_M_P+
        C_C_P+
        C_F_P+
        C_T_P+
        C_L_P+
        C_S_P
    )

    Cold_Drink_Price.set("Rs. " + str(total_Cold_Drinks_Price))
    D_tax = round((total_Cold_Drinks_Price * 0.05), 2)  # round means Showing value 2 digit After Decimal
    Cold_Drink_Tax.set("Rs. " + str(D_tax))


    Total_Bill = float(
        total_Cosmetic_Price+
        total_Grocery_Price+
        total_Cold_Drinks_Price+
        C_tax+
        G_Tax+
        D_tax
    )




frame = LabelFrame(root,text='Customer Details',font=('times new romen',20),fg='yellow',bg='blue',bd=10)
frame.place(x=0,y=68,relwidth=1)

cname_lbl = Label(frame,text='Customer Name',font=('times new romen',18,'bold'),fg='white',bg='blue')
cname_lbl.grid(row=0,column=0)
phone_lbl = Label(frame,text='Customer Phone No.',font=('times new romen',18,'bold'),fg='white',bg='blue')
phone_lbl.grid(row=0,column=3)
bill_lbl = Label(frame,text='Bill Number',font=('times new romen',18,'bold'),fg='white',bg='blue')
bill_lbl.grid(row=0,column=5)

# Created entry:

entry1 = Entry(frame,width=15,relief=SUNKEN,font=('arial',15),bd=7,textvariable = C_Name)
entry1.grid(row=0,column=1,padx=15,pady=7)
entry2 = Entry(frame,width=15,relief=SUNKEN,font=('arial',15),bd=7,textvariable=Phone_No)
entry2.grid(row=0,column=4,padx=15,pady=7)
entry3 = Entry(frame,width=15,relief=SUNKEN,font=('arial',15),bd=7,textvariable=Bill_No)
entry3.grid(row=0,column=6,padx=20,pady=7)


btn1 = Button(frame,text='Search',font=('times new romen',20),width=10,bd=7)
btn1.grid(row=0,column=8,padx = 20,pady=10)

frame2 = LabelFrame(root,text='Cosmetics',font=('times new romen',20),fg='yellow',bg='blue',bd=10)
frame2.place(x=0,y=180,width=350,height=400)

bath = Label(frame2,text='Bath Soap',font=('arial',20,'bold'),fg='pink',bg='blue')
bath.grid(row=0,column=0,sticky='w',pady=10)
f_cream = Label(frame2,text='Face Cream',font=('arial',20,'bold'),fg='pink',bg='blue')
f_cream.grid(row=1,column=0,sticky='w',pady=10)
f_wash = Label(frame2,text='Face Wash',font=('arial',20,'bold'),fg='pink',bg='blue')
f_wash.grid(row=2,column=0,sticky='w',pady=10)
h_spray = Label(frame2,text='Hair spray',font=('arial',20,'bold'),fg='pink',bg='blue')
h_spray.grid(row=3,column=0,sticky='w',pady=10)
h_gel = Label(frame2,text='Hair Gel',font=('arial',20,'bold'),fg='pink',bg='blue')
h_gel.grid(row=4,column=0,sticky='w',pady=10)
b_loshan = Label(frame2,text='Body Loshan',font=('arial',20,'bold'),fg='pink',bg='blue')
b_loshan.grid(row=5,column=0,sticky='w',pady=10)

# Create Entry For Above:

entry4 = Entry(frame2,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Soap)
entry4.grid(row=0,column=1,padx=10)
entry5 = Entry(frame2,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Face_Cream)
entry5.grid(row=1,column=1,padx=10)
entry6 = Entry(frame2,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Face_Wash)
entry6.grid(row=2,column=1,padx=10)
entry7 = Entry(frame2,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Hair_Spray)
entry7.grid(row=3,column=1,padx=10)
entry8 = Entry(frame2,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Hair_Gel)
entry8.grid(row=4,column=1,padx=10)
entry9 = Entry(frame2,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Body_Loshan)
entry9.grid(row=5,column=1,padx=10)

# Creatating a frame Grocery:

frame3 = LabelFrame(root,text='Grocery',font=('times new romen',20),fg='yellow',bg='blue',relief=GROOVE,bd=10)
frame3.place(x=350,y=180,width=320,height=400)
  # ******creating labels*******

rice_lbl=Label(frame3,text='Rice',font=('arial',20,'bold'),fg='pink',bg='blue')
rice_lbl.grid(row=0,column=0,sticky='w',pady=10)
f_oil_lbl=Label(frame3,text='Food Oil',font=('arial',20,'bold'),fg='pink',bg='blue')
f_oil_lbl.grid(row=1,column=0,sticky='w',pady=10)
daal_lbl=Label(frame3,text='Daal',font=('arial',20,'bold'),fg='pink',bg='blue')
daal_lbl.grid(row=2,column=0,sticky='w',pady=10)
wheat_lbl=Label(frame3,text='Wheat',font=('arial',20,'bold'),fg='pink',bg='blue')
wheat_lbl.grid(row=3,column=0,sticky='w',pady=10)
sugar_lbl=Label(frame3,text='Sugar',font=('arial',20,'bold'),fg='pink',bg='blue')
sugar_lbl.grid(row=4,column=0,sticky='w',pady=10)
tea_lbl=Label(frame3,text='Tea',font=('arial',20,'bold'),fg='pink',bg='blue')
tea_lbl.grid(row=5,column=0,sticky='w',pady=10)

entry10 = Entry(frame3,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Rice)
entry10.grid(row=0,column=1,padx=20)
entry11 = Entry(frame3,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Food_Oil)
entry11.grid(row=1,column=1,padx=10)
entry12 = Entry(frame3,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Daal)
entry12.grid(row=2,column=1,padx=10)
entry13 = Entry(frame3,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Wheat)
entry13.grid(row=3,column=1,padx=10)
entry14 = Entry(frame3,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Sugar)
entry14.grid(row=4,column=1,padx=10)
entry15 = Entry(frame3,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Tea)
entry15.grid(row=5,column=1,padx=10)

frame4 = LabelFrame(root,text='Cold Drinks',font=('times new romen',20),fg='yellow',bg='blue',relief=GROOVE,bd=10)
frame4.place(x=670,y=180,width=350,height=400)

maza_lbl=Label(frame4,text='Maza',font=('arial',20,'bold'),fg='pink',bg='blue')
maza_lbl.grid(row=0,column=0,sticky='w',pady=10)
cock_lbl=Label(frame4,text='Cock',font=('arial',20,'bold'),fg='pink',bg='blue')
cock_lbl.grid(row=1,column=0,sticky='w',pady=10)
frooti_lbl=Label(frame4,text='Frooti',font=('arial',20,'bold'),fg='pink',bg='blue')
frooti_lbl.grid(row=2,column=0,sticky='w',pady=10)
thumbs_lbl=Label(frame4,text='Thumbs Up',font=('arial',20,'bold'),fg='pink',bg='blue')
thumbs_lbl.grid(row=3,column=0,sticky='w',pady=10)
limca_lbl=Label(frame4,text='Limca',font=('arial',20,'bold'),fg='pink',bg='blue')
limca_lbl.grid(row=4,column=0,sticky='w',pady=10)
sprite_lbl=Label(frame4,text='Sprite',font=('arial',20,'bold'),fg='pink',bg='blue')
sprite_lbl.grid(row=5,column=0,sticky='w',pady=10)

entry10 = Entry(frame4,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Maza)
entry10.grid(row=0,column=1,padx=20)
entry11 = Entry(frame4,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Cock)
entry11.grid(row=1,column=1,padx=10)
entry12 = Entry(frame4,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Frooti)
entry12.grid(row=2,column=1,padx=10)
entry13 = Entry(frame4,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Thumbs_Up)
entry13.grid(row=3,column=1,padx=10)
entry14 = Entry(frame4,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Limca)
entry14.grid(row=4,column=1,padx=10)
entry15 = Entry(frame4,width=10,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Sprite)
entry15.grid(row=5,column=1,padx=10)

frame5 = LabelFrame(root,text='Bill Menu',font=('times new romen',20),fg='yellow',bg='blue',relief=GROOVE,bd=10)
frame5.place(x=0,y=580,relwidth=1,height=250)

t_c_p_lbl=Label(frame5,text='Total Cosmetic Price',font=('arial',20,'bold'),fg='pink',bg='blue')
t_c_p_lbl.grid(row=0,column=0,sticky='w',pady=15)
t_g_p_lbl=Label(frame5,text='Total Grocery Price',font=('arial',20,'bold'),fg='pink',bg='blue')
t_g_p_lbl.grid(row=1,column=0,sticky='w',pady=15)
t_cold_lbl=Label(frame5,text='Total Cold Drinks Price',font=('arial',20,'bold'),fg='pink',bg='blue')
t_cold_lbl.grid(row=2,column=0,sticky='w',pady=15)

entry16 = Entry(frame5,width=15,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Cosmetic_Price)
entry16.grid(row=0,column=1,padx=10)
entry17 = Entry(frame5,width=15,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Grocery_Price)
entry17.grid(row=1,column=1,padx=10)
entry18 = Entry(frame5,width=15,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Cold_Drink_Price)
entry18.grid(row=2,column=1,padx=10)

c_tax_lbl=Label(frame5,text='Cosmetic Tax',font=('arial',20,'bold'),fg='pink',bg='blue')
c_tax_lbl.grid(row=0,column=2,sticky='w',pady=15,padx=20)
g_tax_lbl=Label(frame5,text='Grocery Tax',font=('arial',20,'bold'),fg='pink',bg='blue')
g_tax_lbl.grid(row=1,column=2,sticky='w',pady=15,padx=20)
cold_tax_lbl=Label(frame5,text='Cold Drink Tax',font=('arial',20,'bold'),fg='pink',bg='blue')
cold_tax_lbl.grid(row=2,column=2,sticky='w',pady=15,padx=20)

entry16 = Entry(frame5,width=15,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Cosmetic_Tax)
entry16.grid(row=0,column=3,padx=10)
entry17 = Entry(frame5,width=15,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Grocery_Tax)
entry17.grid(row=1,column=3,padx=10)
entry18 = Entry(frame5,width=15,bd=7,font=('arial',15),relief=SUNKEN,textvariable=Cold_Drink_Tax)
entry18.grid(row=2,column=3,padx=10)

frame7 = Frame(root, relief=GROOVE, bd=10)
frame7.place(x=970, y=630, width=605, height=170)

total_btn = Button(frame7,text='Total',font=('bold',23),bg='green',relief=GROOVE,command = total)
total_btn.grid(row=0,column=0,pady=40,padx=10)
total_btn = Button(frame7,text='Generate Bill',font=('bold',23),bg='green',relief=GROOVE)
total_btn.grid(row=0,column=1,pady=40,padx=10)
total_btn = Button(frame7,text='Clear',font=('bold',23),bg='green',relief=GROOVE)
total_btn.grid(row=0,column=2,pady=40,padx=10)
total_btn = Button(frame7,text='Exit',font=('bold',23),bg='green',relief=GROOVE,command=custom_quit)
total_btn.grid(row=0,column=3,pady=40,padx=10)



bill_frame = Frame(root,bg='white',relief = GROOVE,bd=10)
bill_frame.place(x=1020,y=190,width=580,height=380)

bill_lbl = Label(bill_frame,text='Bill Area',font=('ariel',30,'bold'),bg='yellow',fg='black',relief = GROOVE,bd=7)
bill_lbl.pack(fill=X)

scroll_y = Scrollbar(bill_frame,orient=VERTICAL)
textarea = Text(bill_frame,yscrollcommand=scroll_y.set)
scroll_y.pack(side=RIGHT,fill=Y)
scroll_y.config(command=textarea.yview)
textarea.pack()

# ***********









root.mainloop()