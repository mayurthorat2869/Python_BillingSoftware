# This is Project Of Billing Software:
# important Comment : textvariable is a attribute of entry
from tkinter import *
import math,random,os
from tkinter import messagebox


class Bill_App:


    def __init__(self,root):
        self.root = root
        self.root.geometry("1400x700+0+0")
        self.root.title("Billing Software With Mayur Thorat")
        title = Label(self.root,text="Billing Software",bd=12,relief=GROOVE,font=("times new romen",20,"bold"),pady=2,bg="blue",fg="white")
        title.pack(fill="both")

    # This is Actual Backend Data Fillings:
    # ================== Create All Variables=================
    # ================== Cosmetics ===========================
        self.Soap = IntVar()
        self.Face_Cream = IntVar()
        self.Face_Wash = IntVar()
        self.Spray = IntVar()
        self.Gel = IntVar()
        self.Loshan = IntVar()
    # ================== Grosery Variables ===================
        self.Rice = IntVar()
        self.Food_Oil = IntVar()
        self.Daal = IntVar()
        self.Wheat = IntVar()
        self.Sugar = IntVar()
        self.Tea = IntVar()
    # ================== Cold Drinks Variables ================
        self.Maza = IntVar()
        self.Cock = IntVar()
        self.Frooti = IntVar()
        self.Thumbs_Up = IntVar()
        self.Limca = IntVar()
        self.Sprite = IntVar()

    # ----------------- Total Product Price & Tax Variables ------------------
        self.Cosmetic_Price = StringVar()
        self.Grosery_Price = StringVar()
        self.Cold_Drink_Price = StringVar()

        self.Cosmetic_Tax = StringVar()
        self.Grocery_Tax = StringVar()
        self.Cold_Drink_Tax = StringVar()

    # Customer Variable:
        self.C_Name = StringVar()
        self.C_Phone = StringVar()
        self.Bill_No = StringVar()
        x = random.randint(1000, 9999)
        self.Bill_No.set(str(x))

        self.Search_Bill = StringVar()              #  This All Variables   are called in below by using textvariable



    # *************Customer Details Frame************

        frame1 = LabelFrame(self.root,text="Customer Details",font =("times new roman",15,"bold"),bg="blue",fg="yellow",bd=10,relief=GROOVE)
        frame1.place(x=0,y=60,relwidth=1)                      # LabelFrame used then place function used

    # Below Strats Labels:-
        cname_lbl = Label(frame1,text = "Customer Name",font=("times new roman",15,"bold"),bg="blue",fg="white")   # Create Customer Name Label:
        cname_lbl.grid(row=0,column=0)

        phone_lbl = Label(frame1, text="Customer Phone No.", font=("times new roman", 15, "bold"), bg="blue", fg="white")
        phone_lbl.grid(row=0, column=2)

        bill_lbl = Label(frame1, text="Bill Number", font=("times new roman", 15, "bold"), bg="blue", fg="white")
        bill_lbl.grid(row=0, column=5)

     # Below Starts Entry:-
        entry1 = Entry(frame1,width=15,font=("arial",12),bd=7,relief=SUNKEN,textvariable =self.C_Name)        # Type of relief = SUNKEN,GROOVE.
        entry1.grid(row=0,column=1,pady=5,padx=10)

        entry2 = Entry(frame1, width=15, font=("arial", 12), bd=7, relief=SUNKEN,textvariable =self.C_Phone)  # Type of relief = SUNKEN,GROOVE.
        entry2.grid(row=0, column=3, pady=5, padx=10)

        entry3 = Entry(frame1, width=15, font=("arial", 12), bd=7, relief=SUNKEN,textvariable = self.Search_Bill)  # Type of relief = SUNKEN,GROOVE.
        entry3.grid(row=0, column=6, pady=5, padx=10)

     # Below is Create A Button: in frame 1
        bill_btn = Button(frame1,text = "Search",command = self.find_bill,width=5,bd=7,font=("arial",12,"bold"))
        bill_btn.grid(row=0,column=7,pady =5)

    # Below Create Cosmetic Frame:-

        frame2 = LabelFrame(self.root,text = "Cosmetics",font = ("times new roman",15,"bold"),fg="yellow",bg="blue",bd=7,relief=GROOVE)
        frame2.place(x=0,y=145,width=250,height=330)

        # Create Labels: For Frame2

        bath = Label(frame2,text= "Bath Soap",font=("times new roman",15,"bold"),fg="pink",bg="blue")
        bath.grid(row=0,column=0,padx=10,pady=10,sticky="w")

        F_Cream = Label(frame2, text="Face Cream", font=("times new roman", 15, "bold"), fg="pink", bg="blue")
        F_Cream.grid(row=1, column=0, padx=10, pady=10,sticky="w")

        F_Wash = Label(frame2, text="Face Wash", font=("times new roman", 15, "bold"), fg="pink", bg="blue")
        F_Wash.grid(row=2, column=0, padx=10, pady=10,sticky="w")

        H_Spray = Label(frame2, text="Hair Spray", font=("times new roman", 15, "bold"), fg="pink", bg="blue")
        H_Spray.grid(row=3, column=0, padx=10, pady=10,sticky="w")

        H_Gel = Label(frame2, text="Hair Gel", font=("times new roman", 15, "bold"), fg="pink", bg="blue")
        H_Gel.grid(row=4, column=0, padx=10, pady=10,sticky="w")

        B_Loshan = Label(frame2, text="Body Loshan", font=("times new roman", 15, "bold"), fg="pink", bg="blue")
        B_Loshan.grid(row=5, column=0, padx=10, pady=10,sticky="w")

        # Create Entry: For Frame2

        entry4 = Entry(frame2,width=7,font=("arial",15),bd=7,relief=SUNKEN,textvariable = self.Soap)
        entry4.grid(row=0,column=1)
        entry5 = Entry(frame2, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Face_Cream)
        entry5.grid(row=1, column=1)
        entry6 = Entry(frame2, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Face_Wash)
        entry6.grid(row=2, column=1)
        entry7 = Entry(frame2, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Spray)
        entry7.grid(row=3, column=1)
        entry8 = Entry(frame2, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Gel)
        entry8.grid(row=4, column=1)
        entry9 = Entry(frame2, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Loshan)
        entry9.grid(row=5, column=1)

        # Create A Frame 3:-

        frame3 = LabelFrame(self.root,text="Grocery",font=("times new roman",15,"bold"),fg="yellow",bg="blue",bd=7,relief=GROOVE)
        frame3.place(x=250,y=145,width=250,height=330)

        # Create Label For Frame 3:-

        rice_lbl = Label(frame3,text="Rice",font=("times new roman",15,"bold"),fg="pink",bg="blue")
        rice_lbl.grid(row=0,column=1,padx=10,pady=10,sticky="w")
        F_Oil_lbl = Label(frame3, text="Food Oil", font=("times new roman", 15, "bold"), fg="pink", bg="blue")
        F_Oil_lbl.grid(row=1, column=1, padx=10, pady=10,sticky="w")
        Daal_lbl = Label(frame3, text="Daal", font=("times new roman", 15, "bold"), fg="pink", bg="blue")
        Daal_lbl.grid(row=2, column=1, padx=10, pady=10,sticky="w")
        Wheat_lbl = Label(frame3, text="Wheat", font=("times new roman", 15, "bold"), fg="pink", bg="blue")
        Wheat_lbl.grid(row=3, column=1, padx=10, pady=10,sticky="w")
        Shugar_lbl = Label(frame3, text="Sugar", font=("times new roman",15, "bold"), fg="pink", bg="blue")
        Shugar_lbl.grid(row=4, column=1, padx=10, pady=10,sticky="w")
        Tea_lbl = Label(frame3, text="Tea", font=("times new roman",15, "bold"), fg="pink", bg="blue")
        Tea_lbl.grid(row=5, column=1, padx=10, pady=10,sticky="w")

        # Create Entry For Frame3:

        entry10 = Entry(frame3,width=7,font=("arial",15),bd=7,relief=SUNKEN,textvariable =self.Rice)
        entry10.grid(row=0,column=2,padx=30)
        entry11 = Entry(frame3, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Food_Oil)
        entry11.grid(row=1, column=2, padx=20)
        entry12 = Entry(frame3, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Daal)
        entry12.grid(row=2, column=2, padx=20)
        entry13 = Entry(frame3, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Wheat)
        entry13.grid(row=3, column=2, padx=20)
        entry14 = Entry(frame3, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Sugar)
        entry14.grid(row=4, column=2, padx=20)
        entry15 = Entry(frame3, width=7, font=("arial", 15), bd=7, relief=SUNKEN,textvariable =self.Tea)
        entry15.grid(row=5, column=2, padx=20)

        # Create A frame 4: Cold Drinks:

        frame4 = LabelFrame(self.root,text = "Cold Drinks",font=("times new roman",15),bg="blue",fg="yellow",bd=7,relief=GROOVE)
        frame4.place(x=500,y=145,width=250,height=330)

        # Create A Label for frame4:                                                      # textvariable menas assigning the above variables..

        M_lbl = Label(frame4,text="Maza",font=("arial",15,"bold"),fg="pink",bg="blue")
        M_lbl.grid(row=0,column=0,sticky="w",padx=10,pady=10)
        C_lbl = Label(frame4, text="Cock", font=("arial", 15, "bold"), fg="pink", bg="blue")
        C_lbl.grid(row=1, column=0, sticky="w", padx=10, pady=10)
        F_lbl = Label(frame4, text="Frooti", font=("arial", 15, "bold"), fg="pink", bg="blue")
        F_lbl.grid(row=2, column=0, sticky="w", padx=10, pady=10)
        T_lbl = Label(frame4, text="Thumbs Up", font=("arial", 15, "bold"), fg="pink", bg="blue")
        T_lbl.grid(row=3, column=0, sticky="w", padx=10, pady=10)
        L_lbl = Label(frame4, text="Limca", font=("arial", 15, "bold"), fg="pink", bg="blue")
        L_lbl.grid(row=4, column=0, sticky="w", padx=10, pady=10)
        S_lbl = Label(frame4, text="Sprite", font=("arial", 15, "bold"), fg="pink", bg="blue")
        S_lbl.grid(row=5, column=0, sticky="w", padx=10, pady=10)

        # Create A Entry For Frame4:

        entry16 = Entry(frame4,width=7,font=("aril",15),bd=7,relief=SUNKEN,textvariable =self.Maza)
        entry16.grid(row=0,column=1)
        entry17 = Entry(frame4, width=7, font=("aril", 15), bd=7, relief=SUNKEN,textvariable =self.Cock)
        entry17.grid(row=1, column=1)
        entry18 = Entry(frame4, width=7, font=("aril", 15), bd=7, relief=SUNKEN,textvariable =self.Frooti)
        entry18.grid(row=2, column=1)
        entry19 = Entry(frame4, width=7, font=("aril", 15), bd=7, relief=SUNKEN,textvariable =self.Thumbs_Up)
        entry19.grid(row=3, column=1)
        entry20 = Entry(frame4, width=7, font=("aril", 15), bd=7, relief=SUNKEN,textvariable =self.Limca)
        entry20.grid(row=4, column=1)
        entry21 = Entry(frame4, width=7, font=("aril", 15), bd=7, relief=SUNKEN,textvariable =self.Sprite)
        entry21.grid(row=5, column=1)

        # Create A Frame of Billing Area:
        # Here Not Require for Label Frame Because not giving name to frame:
        frame5 = Frame (self.root,bg="white",relief=GROOVE,bd=10)
        frame5.place(x=750,y=145,width=270,height=330)

        # Create Bill Title:

        bill_title = Label(frame5,text="Bill Area",font = ("arial",15,"bold"),bd=7,relief=GROOVE)
        bill_title.pack(fill=X)

        # Create Scroll Bar:

        scroll_y = Scrollbar(frame5,orient =VERTICAL)                                                        # This is importance
        self.textarea = Text(frame5,yscrollcommand =scroll_y.set)
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_y.config(command=self.textarea.yview)
        self.textarea.pack()

        # Create A Frame For Bill Menu:

        frame6 = LabelFrame(self.root,text="Bill Menu",bd=10,relief=GROOVE,bg="blue",font=("times new roman",15),fg="yellow")
        frame6.place(x=0,y=470,relwidth=1,height=240)

        # Adding The Label in Frame6:

        T_Cos=Label(frame6,text="Total Cosmetic Price",font=("times new roman",18,"bold"),fg="pink",bg="blue")
        T_Cos.grid(row=0, column=0, padx=2, pady=5,sticky="w")

        T_Gro_lbl = Label(frame6, text="Total Grosery Price", font=("times new roman", 18, "bold"), fg="pink", bg="blue")
        T_Gro_lbl.grid(row=1, column=0, padx=2, pady=5,sticky="w")

        T_Cold = Label(frame6, text="Total Cold Drink Price", font=("times new roman", 18, "bold"), fg="pink", bg="blue")
        T_Cold.grid(row=3,column=0,padx=2,pady=5,sticky="w")

        # Create A Entry For Frame7:

        entry22 = Entry(frame6,font=("arial",15),relief=SUNKEN,width=8,bd=7,textvariable =self.Cosmetic_Price)
        entry22.grid(row=0,column=1,padx=15,pady=15)
        entry23 = Entry(frame6, font=("arial", 15), relief=SUNKEN, width=8, bd=7,textvariable =self.Grosery_Price)
        entry23.grid(row=1, column=1,padx=15,pady=15)
        entry24 = Entry(frame6, font=("arial", 15), relief=SUNKEN, width=8, bd=7,textvariable =self.Cold_Drink_Price)
        entry24.grid(row=3, column=1,padx=15,pady=15)

        # Create A Label for Same Frame 6:

        c_t_lbl = Label(frame6,text="Cosmetic Tax",font=("times new roman",18,"bold"),fg="pink",bg="blue")
        c_t_lbl.grid(row=0,column=2,sticky="w",padx=15)
        g_t_lbl = Label(frame6, text="Grosery Tax", font=("times new roman", 18, "bold"), fg="pink", bg="blue")
        g_t_lbl.grid(row=1, column=2, sticky="w",padx=15)
        C_t_lbl = Label(frame6, text="Cold Drink Tax", font=("times new roman", 18, "bold"), fg="pink", bg="blue")
        C_t_lbl.grid(row=3, column=2, sticky="w",padx=15)

        # Create A Entry for above lables:

        entry25 = Entry(frame6,font=("arial",15),relief=SUNKEN,width=8,bd=7,textvariable =self.Cosmetic_Tax)
        entry25.grid(row=0,column=3)
        entry26 = Entry(frame6, font=("arial", 15), relief=SUNKEN, width=8, bd=7,textvariable =self.Grocery_Tax)
        entry26.grid(row=1, column=3)
        entry27 = Entry(frame6, font=("arial", 15), relief=SUNKEN, width=8, bd=7,textvariable =self.Cold_Drink_Tax)
        entry27.grid(row=3, column=3)

        # Create Another Frame For Buttons:

        frame7= Frame(self.root,relief=GROOVE,bd=10)
        frame7.place(x=700,y=560,width=320,height=100)

        # Create A Buttons For Above Frame:

        Total_button = Button(frame7,text="Total",font=("times new roman",10),relief=GROOVE,bd=7,bg="green",command=self.total) # Here Calling The total Function
        Total_button.grid(row=0,column=0,padx=10,pady=25)

        Generate_btn=Button(frame7,text="Generate Bill",font=("times new roman",10),relief=GROOVE,bd=7,bg="green",width=10,command=self.Bill_Area)
        Generate_btn.grid(row=0,column=1,padx=10,pady=25)

        clear_btn = Button(frame7, text="Clear", font=("times new roman", 10), relief=GROOVE, bd=7, bg="green",command = self.clear_data)
        clear_btn.grid(row=0, column=2,padx=10,pady=25)

        Exit_btn = Button(frame7, text="Exit", font=("times new roman", 10), relief=GROOVE, bd=7, bg="red", command =quit)
        Exit_btn.grid(row=0, column=3,padx=10,pady=25)

        self.Welcome_Bill()                                        # Automatically Calling Welcome Fuunction

    # Below For Cosmetics:
    def total(self):                                               # 40,120,60 like are prices..
        self.C_S_P= self.Soap.get()*40                                                 # C_S_P menas Cosmetic Soap Price
        self.C_FC_P= self.Face_Cream.get()*120
        self.C_FW_P= self.Face_Wash.get()*60
        self.C_HS_P= self.Spray.get()*67
        self.C_HG_P= self.Gel.get()*140
        self.C_BL_P= self.Loshan.get()*180                         # Here Defined The All Prices

        self.total_Cosmetic_price=float(                          # Here Convert into Float Because Required Float Value

             self.C_S_P+
             self.C_FC_P+
             self.C_FW_P+
             self.C_HS_P+
             self.C_HG_P+
             self.C_BL_P
        )
        self.Cosmetic_Price.set("Rs. "+str(self.total_Cosmetic_price))
        self.C_tax=round((self.total_Cosmetic_price*0.05),2)
        self.Cosmetic_Tax.set("Rs. "+str(self.C_tax))         # Means 5% Tax on Cosmetics Prices
        # Next We Used Grocery Price:

        self.G_R_P = self.Rice.get() * 180
        self.G_F_P = self.Food_Oil.get() * 180
        self.G_D_P = self.Daal.get() * 60
        self.G_W_P = self.Wheat.get() * 240
        self.G_S_P = self.Sugar.get() * 45
        self.G_T_P = self.Tea.get() * 150                                        # Here Defined The All Prices

        self.total_Grocery_price = float(                                 # Here Convert into Float Because Required Float Value
            self.G_R_P+
            self.G_F_P+
            self.G_D_P+
            self.G_W_P+
            self.G_S_P+
            self.G_T_P
        )


        self.Grosery_Price.set("Rs. "+str(self.total_Grocery_price))
        self.G_tax=round((self.total_Grocery_price * 0.1),2)
        self.Grocery_Tax.set("Rs. "+str(self.G_tax))

        # Next Giving Price For ColdDrinks:

        self.D_M_P=self.Maza.get() * 60
        self.D_C_P=self.Cock.get() * 60
        self.D_F_P=self.Frooti.get() * 50
        self.D_T_P=self.Thumbs_Up.get() * 45
        self.D_L_P=self.Limca.get() * 40
        self.D_S_P=self.Sprite.get() * 60  # Here Defined The All Prices

        self.total_Cold_Drinks_price = float(                                       # Here Convert into Float Because Required Float Value

            self.D_M_P+
            self.D_C_P+
            self.D_F_P+
            self.D_T_P+
            self.D_L_P+
            self.D_S_P
        )

        self.Cold_Drink_Price.set("Rs. "+str(self.total_Cold_Drinks_price))
        self.D_tax = round((self.total_Cold_Drinks_price * 0.05),2)    # round means Showing value 2 digit After Decimal
        self.Cold_Drink_Tax.set("Rs. "+str(self.D_tax))

        # Create The All products Final Sum:
        self.Total_Bill = float(self.total_Cosmetic_price+
                                self.total_Grocery_price+
                                self.total_Cold_Drinks_price+
                                self.C_tax+
                                self.G_tax+
                                self.D_tax
                            )                       # This is required to print in Bill Area


        # Showing The All Data in Bill Area So Below Operations:
    def Welcome_Bill(self):
        self.textarea.delete('1.0',END)
        self.textarea.insert(END, "\t \t \t \t Welcome Webcode Retail\n")                         # \t is a tab giving
        self.textarea.insert(END, f"\n Bill Number : {self.Bill_No.get()} ")
        self.textarea.insert(END, f"\n Customer Name : {self.C_Name.get()}")
        self.textarea.insert(END, f"\n Phone Number : {self.C_Phone.get()}")                 # Calling All Variables
        self.textarea.insert(END, f"\n ===========================")
        self.textarea.insert(END,f"\n Products   \tQTY     \tPrice")                      # Tab addes according to requirements
        self.textarea.insert(END, f"\n ===========================")


    def Bill_Area(self):
        if self.C_Name.get()=="" or self.C_Phone.get()=="":
            messagebox.showerror("Error","Customer Details Are Must")
        elif self.Cosmetic_Price.get()=="Rs. 0.0" and self.Grosery_Price.get()=="Rs. 0.0" and self.Cold_Drink_Price.get()=="Rs. 0.0":
            messagebox.showerror("Error","No Product Purchased")


        else:
            self.Welcome_Bill()
            # Cosmetics: For Text Area:
            if self.Soap.get() !=0:                                                # This function used because in screen have a product price 0 then not showing bill
                self.textarea.insert(END,f"\n Bath Soap\t   {self.Soap.get()}\t\t{self.C_S_P}")
            if self.Face_Cream.get() !=0:
                self.textarea.insert(END,f"\n Face Cream\t  {self.Face_Cream.get()}\t\t{self.C_FC_P}")
            if self.Face_Wash.get() !=0:
                self.textarea.insert(END,f"\n Face Wash\t   {self.Face_Wash.get()}\t\t{self.C_FW_P}")
            if self.Spray.get() !=0:
                self.textarea.insert(END,f"\n Spray\t      {self.Spray.get()}\t\t{self.C_HS_P}")
            if self.Gel.get() !=0:
                self.textarea.insert(END,f"\n Hair Gel\t    {self.Gel.get()}\t\t{self.C_HG_P}")
            if self.Loshan.get() !=0:
                self.textarea.insert(END,f"\n Loshan\t      {self.Loshan.get()}\t\t{self.C_BL_P}")

            # Grocery: For Text Area:
            if self.Rice.get() != 0:                              # This function used because in screen have a product price 0 then not showing bill
                self.textarea.insert(END, f"\n Rice\t      {self.Rice.get()}\t\t{self.G_R_P}")
            if self.Food_Oil.get() != 0:
                self.textarea.insert(END, f"\n Food Oil\t    {self.Food_Oil.get()}\t\t{self.G_F_P}")
            if self.Daal.get() != 0:
                self.textarea.insert(END, f"\n Daal\t      {self.Daal.get()}\t\t{self.G_D_P}")
            if self.Wheat.get() != 0:
                self.textarea.insert(END, f"\n Wheat\t      {self.Wheat.get()}\t\t{self.G_W_P}")
            if self.Sugar.get() != 0:
                self.textarea.insert(END, f"\n Sugar\t      {self.Sugar.get()}\t\t{self.G_S_P}")
            if self.Tea.get() != 0:
                self.textarea.insert(END, f"\n Tea\t      {self.Tea.get()}\t\t{self.G_T_P}")

            # Cold Drinks: For Text Area:
            if self.Maza.get() != 0:  # This function used because in screen have a product price 0 then not showing bill
                self.textarea.insert(END, f"\n Maza\t      {self.Maza.get()}\t\t{self.D_M_P}")
            if self.Cock.get() != 0:
                self.textarea.insert(END, f"\n Cock\t      {self.Cock.get()}\t\t{self.D_C_P}")
            if self.Frooti.get() != 0:
                self.textarea.insert(END, f"\n Frooti\t      {self.Frooti.get()}\t\t{self.D_F_P}")
            if self.Thumbs_Up.get() != 0:
                self.textarea.insert(END, f"\n Thumbs_UP\t   {self.Thumbs_Up.get()}\t\t{self.D_T_P}")
            if self.Limca.get() != 0:
                self.textarea.insert(END, f"\n Limca\t      {self.Limca.get()}\t\t{self.D_L_P}")
            if self.Sprite.get() != 0:
                self.textarea.insert(END, f"\n Sprite\t      {self.Sprite.get()}\t\t{self.D_S_P}")

            self.textarea.insert(END, f"\n ---------------------------")
            if self.Cosmetic_Tax.get() != "RS. 0.0":
                self.textarea.insert(END, f"\n Cosmetics   : \t  {self.Cosmetic_Tax.get()}")  # Tab addes according to requirements
            if self.Grocery_Tax.get() != "RS. 0.0":
                self.textarea.insert(END, f"\n Grocery     : \t  {self.Grocery_Tax.get()}")
            if self.Cold_Drink_Tax.get() != "RS. 0.0":
                self.textarea.insert(END, f"\n Cold Drink  : \t  {self.Cold_Drink_Tax.get()}")

        self.textarea.insert(END, f"\n Total Bill  : \t\t Rs. {str(self.Total_Bill)}")  # Here Calling The Total  Bill
        self.textarea.insert(END, f"\n ---------------------------")

        self.Save_Bill()


    def Save_Bill(self):
        op = messagebox.askyesno("Save Bill","Do You Want to Save The Bill?")
        if op>0:
            self.Bill_Data= self.textarea.get("1.0",END)
            f1=open(str(self.Bill_No.get())+".txt","w")
            f1.write(self.Bill_Data)
            f1.close()
            messagebox.showinfo("Saved",f"Bill NO. : {self.Bill_No.get()} Saved Succesfully")
        else:
            return

    def find_bill(self):
        present = "no"
        for i in os.listdir(r'C:\Users\Sanket Pokharkar\Desktop\BILLING SOFTWARE BIG PROJECT\Bills'):
            if i.split('.')[0]==self.Search_Bill.get():
                f1=open(r'C:\Users\Sanket Pokharkar\Desktop\BILLING SOFTWARE BIG PROJECT\Bills'+i,"r")
                self.textarea.delete("1.0",END)
                for d in f1:
                    self.textarea.insert(END,d)
                f1.close()
                present ="yes"
        if present == 'no':
            messagebox.showerror("Error","Invalid Bill No.")

    def clear_data(self):
        # ================== Cosmetics ===========================
            self.Soap.set(0)
            self.Face_Cream.set(0)
            self.Face_Wash.set(0)
            self.Spray.set(0)
            self.Gel.set(0)
            self.Loshan.set(0)
        # ================== Grosery Variables ===================
            self.Rice.set(0)
            self.Food_Oil.set(0)
            self.Daal.set(0)
            self.Wheat.set(0)
            self.Sugar.set(0)
            self.Tea.set(0)
        # ================== Cold Drinks Variables ================
            self.Maza.set(0)
            self.Cock.set(0)
            self.Frooti.set(0)
            self.Thumbs_Up.set(0)
            self.Limca.set(0)
            self.Sprite.set(0)

        # ----------------- Total Product Price & Tax Variables ------------------
            self.Cosmetic_Price.set("")
            self.Grosery_Price.set("")
            self.Cold_Drink_Price.set("")

            self.Cosmetic_Tax.set("")
            self.Grocery_Tax.set("")
            self.Cold_Drink_Tax.set("")

        # Customer Variable:
            self.C_Name.set("")
            self.C_Phone.set("")
            self.Bill_No.set("")
            x = random.randint(1000, 9999)
            self.Bill_No.set(str(x))

            self.Search_Bill.set("")              #  This All Variables   are called in below by using textvariable
            self.Welcome_Bill()
            




























































































































































































































root = Tk()
obj = Bill_App(root)


root.mainloop()

